// mc1h — raiz do projeto. Não aplica nada diretamente; apenas declara as
// versões dos plugins usadas pelo módulo :app.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
