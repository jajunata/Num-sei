# minifyEnabled está desativado nos dois build types.
# Se ativar futuramente, jadx usa reflection pesada internamente:
# será preciso investigar e adicionar regras -keep específicas antes de confiar no build.
