package com.mc1h.apkdec

import jadx.api.JadxArgs
import jadx.api.JadxDecompiler
import java.io.File

/**
 * Wrapper fino sobre o jadx-core (fork com.github.MuntashirAkon.jadx:jadx-core:1.4.7).
 *
 * NÃO VERIFICADO POR COMPILAÇÃO REAL: este sandbox não tem Android SDK nem
 * acesso de rede para resolver as dependências, então esta chamada não foi
 * compilada/rodada aqui. A API abaixo segue o exemplo oficial da wiki do
 * jadx ("Use jadx as a library", github.com/skylot/jadx/wiki), mas o nome
 * exato de alguns métodos pode variar por versão. Se o build falhar em
 * CI, confira exatamente aqui:
 *
 *  - "unresolved reference: setInputFile"
 *      -> troque para: jadxArgs.inputFiles.add(input)   (campo é uma List<File>)
 *         ou: jadxArgs.addInputFile(input)               (se existir setter dedicado)
 *
 *  - "unresolved reference: setOutDir"
 *      -> essa é a mais estável entre versões; se falhar, procure por
 *         "outDir" / "outDirSrc" / "outDirRes" em jadx.api.JadxArgs.
 *
 *  - erro ao resolver o artefato jadx-dex-input no JitPack
 *      -> confira módulos publicados em
 *         https://jitpack.io/#MuntashirAkon/jadx-android e ajuste o nome
 *         exato do artifact em app/build.gradle.kts.
 */
object JadxRunner {

    /**
     * Decompila [input] (apk ou dex) para [outDir]: código Java + recursos
     * decodificados (AndroidManifest.xml, resources.arsc, etc).
     *
     * Roda de forma síncrona e bloqueante — chame a partir de uma thread de
     * trabalho, nunca da thread principal.
     */
    fun decompile(input: File, outDir: File) {
        outDir.mkdirs()

        val jadxArgs = JadxArgs()
        jadxArgs.setInputFile(input)
        jadxArgs.outDir = outDir

        JadxDecompiler(jadxArgs).use { jadx ->
            jadx.load()
            jadx.save()
        }
    }
}
