package com.mc1h.apkdec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

class DecompileService : Service() {

    private lateinit var scope: CoroutineScope
    private val job = Job()

    override fun onCreate() {
        super.onCreate()
        scope = CoroutineScope(Dispatchers.IO + job)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != Constants.ACTION_START) {
            stopSelf()
            return START_NOT_STICKY
        }

        val apkUri: Uri? = intent.getParcelableExtra(Constants.EXTRA_APK_URI)
        val outTreeUri: Uri? = intent.getParcelableExtra(Constants.EXTRA_OUT_TREE_URI)

        if (apkUri == null || outTreeUri == null) {
            broadcastError("Parâmetros ausentes (APK ou pasta de saída).")
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(Constants.NOTIFICATION_ID, buildNotification("Preparando…"))

        scope.launch {
            runDecompile(apkUri, outTreeUri)
        }

        return START_NOT_STICKY
    }

    private suspend fun runDecompile(apkUri: Uri, outTreeUri: Uri) {
        val inputFile = File(cacheDir, "mc1h_input/input.apk")
        val jadxOutDir = File(cacheDir, "mc1h_jadx_out")

        try {
            updateNotification("Copiando APK selecionado…")
            FileCopyUtils.deleteRecursively(inputFile.parentFile ?: inputFile)
            FileCopyUtils.copyUriToFile(this, apkUri, inputFile)

            updateNotification("Decompilando (pode levar alguns minutos)…")
            FileCopyUtils.deleteRecursively(jadxOutDir)
            JadxRunner.decompile(inputFile, jadxOutDir)

            updateNotification("Copiando resultado para a pasta escolhida…")
            val destTree = DocumentFile.fromTreeUri(this, outTreeUri)
                ?: throw IllegalStateException("Pasta de saída inválida ou permissão perdida.")

            val folderName = "mc1h_" + inputFile.nameWithoutExtension + "_" + System.currentTimeMillis()
            val resultTree = destTree.createDirectory(folderName)
                ?: throw IllegalStateException("Não foi possível criar a pasta de resultado em destino.")

            val fileCount = FileCopyUtils.copyDirToTree(this, jadxOutDir, resultTree)

            updateNotification("Concluído: $fileCount arquivos em '$folderName'.")
            broadcastDone(folderName)
        } catch (e: Exception) {
            updateNotification("Falhou: ${e.message}")
            broadcastError(e.message ?: e.javaClass.simpleName)
        } finally {
            FileCopyUtils.deleteRecursively(inputFile.parentFile ?: inputFile)
            FileCopyUtils.deleteRecursively(jadxOutDir)
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf()
        }
    }

    private fun broadcastDone(folderName: String) {
        val intent = Intent(Constants.ACTION_DONE).putExtra(Constants.EXTRA_OUTPUT_FOLDER_NAME, folderName)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    private fun broadcastError(message: String) {
        val intent = Intent(Constants.ACTION_ERROR).putExtra(Constants.EXTRA_MESSAGE, message)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_ID,
                "Decompilação",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("mc1h Decompiler")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val intent = Intent(Constants.ACTION_PROGRESS).putExtra(Constants.EXTRA_MESSAGE, text)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        getSystemService(NotificationManager::class.java)
            .notify(Constants.NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        job.cancel()
        super.onDestroy()
    }
}
