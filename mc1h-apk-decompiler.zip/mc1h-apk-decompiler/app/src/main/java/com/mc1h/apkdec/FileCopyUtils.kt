package com.mc1h.apkdec

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileOutputStream

object FileCopyUtils {

    /**
     * Copia o conteúdo de um content:// Uri (arquivo selecionado via SAF) para
     * um File local em cache. Necessário porque jadx espera um java.io.File,
     * não um Uri.
     */
    fun copyUriToFile(context: Context, uri: Uri, dest: File) {
        dest.parentFile?.mkdirs()
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalStateException("Não foi possível abrir o APK selecionado (Uri inacessível).")
    }

    /**
     * Copia recursivamente uma árvore de arquivos locais (saída do jadx, em
     * cache) para dentro de uma pasta escolhida pelo usuário via
     * ACTION_OPEN_DOCUMENT_TREE. Necessário por causa do scoped storage:
     * jadx escreve em java.io.File comum, mas a pasta de destino escolhida
     * pelo usuário só é gravável via DocumentFile/SAF.
     *
     * Retorna o número de arquivos copiados.
     */
    fun copyDirToTree(context: Context, srcDir: File, destTree: DocumentFile): Int {
        var count = 0
        val children = srcDir.listFiles() ?: return 0
        for (child in children) {
            if (child.isDirectory) {
                val existing = destTree.findFile(child.name)
                val childTree = if (existing != null && existing.isDirectory) {
                    existing
                } else {
                    destTree.createDirectory(child.name)
                        ?: throw IllegalStateException("Falha ao criar pasta '${child.name}' no destino.")
                }
                count += copyDirToTree(context, child, childTree)
            } else {
                val mime = guessMimeType(child.name)
                // Remove arquivo anterior com mesmo nome para evitar duplicatas
                // tipo "arquivo.java" / "arquivo (1).java" em reexecuções.
                destTree.findFile(child.name)?.delete()
                val newFile = destTree.createFile(mime, child.name)
                    ?: throw IllegalStateException("Falha ao criar arquivo '${child.name}' no destino.")
                context.contentResolver.openOutputStream(newFile.uri)?.use { output ->
                    child.inputStream().use { input -> input.copyTo(output) }
                } ?: throw IllegalStateException("Falha ao abrir saída para '${child.name}'.")
                count += 1
            }
        }
        return count
    }

    private fun guessMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "")
        if (ext.isEmpty()) return "application/octet-stream"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase())
            ?: "application/octet-stream"
    }

    fun deleteRecursively(file: File) {
        if (file.isDirectory) {
            file.listFiles()?.forEach { deleteRecursively(it) }
        }
        file.delete()
    }
}
