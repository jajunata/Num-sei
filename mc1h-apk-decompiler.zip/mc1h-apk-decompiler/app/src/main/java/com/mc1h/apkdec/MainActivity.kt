package com.mc1h.apkdec

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.mc1h.apkdec.databinding.ActivityMainBinding

// ComponentActivity (não AppCompatActivity): evita depender de
// androidx.appcompat e da obrigatoriedade de um tema Theme.AppCompat.*,
// mantendo compatível com o tema android:Theme.Material.* usado em themes.xml.
class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding

    private var apkUri: Uri? = null
    private var outputTreeUri: Uri? = null

    private val pickApk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        apkUri = uri
        binding.textApkSelected.text = uri.lastPathSegment ?: uri.toString()
        updateStartButtonState()
    }

    private val pickOutputDir = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri == null) return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        outputTreeUri = uri
        binding.textOutputSelected.text = uri.lastPathSegment ?: uri.toString()
        updateStartButtonState()
    }

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            startDecompileService()
        }

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Constants.ACTION_PROGRESS -> {
                    val msg = intent.getStringExtra(Constants.EXTRA_MESSAGE) ?: ""
                    binding.textStatus.text = msg
                }
                Constants.ACTION_DONE -> {
                    val folder = intent.getStringExtra(Constants.EXTRA_OUTPUT_FOLDER_NAME) ?: ""
                    binding.progressBar.visibility = android.view.View.GONE
                    binding.textStatus.text = "Concluído. Resultado em: $folder"
                    binding.btnStart.isEnabled = true
                }
                Constants.ACTION_ERROR -> {
                    val msg = intent.getStringExtra(Constants.EXTRA_MESSAGE) ?: "Erro desconhecido"
                    binding.progressBar.visibility = android.view.View.GONE
                    binding.textStatus.text = "Falhou: $msg"
                    binding.btnStart.isEnabled = true
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPickApk.setOnClickListener {
            pickApk.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*"))
        }
        binding.btnPickOutput.setOnClickListener {
            pickOutputDir.launch(null)
        }
        binding.btnStart.setOnClickListener {
            onStartClicked()
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Constants.ACTION_PROGRESS)
            addAction(Constants.ACTION_DONE)
            addAction(Constants.ACTION_ERROR)
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(progressReceiver, filter)
    }

    override fun onStop() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(progressReceiver)
        super.onStop()
    }

    private fun updateStartButtonState() {
        binding.btnStart.isEnabled = apkUri != null && outputTreeUri != null
    }

    private fun onStartClicked() {
        binding.btnStart.isEnabled = false
        binding.progressBar.visibility = android.view.View.VISIBLE
        binding.textStatus.text = "Iniciando…"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startDecompileService()
    }

    private fun startDecompileService() {
        val intent = Intent(this, DecompileService::class.java).apply {
            action = Constants.ACTION_START
            putExtra(Constants.EXTRA_APK_URI, apkUri)
            putExtra(Constants.EXTRA_OUT_TREE_URI, outputTreeUri)
        }
        ContextCompat.startForegroundService(this, intent)
    }
}
