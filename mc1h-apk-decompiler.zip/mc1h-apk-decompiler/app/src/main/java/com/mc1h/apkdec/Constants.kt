package com.mc1h.apkdec

object Constants {
    const val ACTION_START = "com.mc1h.apkdec.action.START"

    const val EXTRA_APK_URI = "com.mc1h.apkdec.extra.APK_URI"
    const val EXTRA_OUT_TREE_URI = "com.mc1h.apkdec.extra.OUT_TREE_URI"

    // Broadcasts locais enviados pelo DecompileService para a MainActivity.
    const val ACTION_PROGRESS = "com.mc1h.apkdec.broadcast.PROGRESS"
    const val ACTION_DONE = "com.mc1h.apkdec.broadcast.DONE"
    const val ACTION_ERROR = "com.mc1h.apkdec.broadcast.ERROR"

    const val EXTRA_MESSAGE = "com.mc1h.apkdec.extra.MESSAGE"
    const val EXTRA_OUTPUT_FOLDER_NAME = "com.mc1h.apkdec.extra.OUTPUT_FOLDER_NAME"

    const val NOTIFICATION_CHANNEL_ID = "mc1h_decompile_channel"
    const val NOTIFICATION_ID = 1001
}
