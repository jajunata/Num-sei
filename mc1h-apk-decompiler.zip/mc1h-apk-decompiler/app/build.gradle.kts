plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mc1h.apkdec"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mc1h.apkdec"
        // jadx-core avisa oficialmente que "pode não funcionar em API < 26"
        // (wiki: github.com/skylot/jadx/wiki/Use-jadx-as-a-library). minSdk 26
        // evita essa faixa não suportada.
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Exigido pelo fork jadx-android (ver release notes 1.4.7):
        // "You must apply desugaring in your app (recommended version: 2.0.3 or later)".
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.localbroadcastmanager:localbroadcastmanager:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // --- Motor de decompilação ---
    // Fork de skylot/jadx mantido especificamente para rodar em Android
    // (usado em produção pelo app AppManager). Publicado via JitPack.
    // Verificar módulos disponíveis em: https://jitpack.io/#MuntashirAkon/jadx-android
    implementation("com.github.MuntashirAkon.jadx:jadx-core:1.4.7")
    implementation("com.github.MuntashirAkon.jadx:jadx-dex-input:1.4.7")

    // jadx depende de slf4j-api; usamos o binding "nop" (sem saída de log)
    // para não puxar uma lib de logging pesada/incompatível com Android.
    implementation("org.slf4j:slf4j-nop:2.0.13")

    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
