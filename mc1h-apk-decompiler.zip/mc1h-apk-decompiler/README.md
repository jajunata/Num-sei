# mc1h Decompiler (Android)

App Android que decompila um APK/DEX **inteiramente no próprio aparelho**,
sem servidor, sem conta e sem permissão de internet declarada no manifest.
Motor: jadx (fork mantido para Android — mesmo usado pelo app AppManager).

Fluxo:
1. Selecionar o APK pelo seletor de arquivos do sistema.
2. Selecionar a pasta de saída (também pelo seletor de arquivos/pastas do sistema).
3. Tocar em "Iniciar" — um serviço em primeiro plano decompila e grava o
   resultado (código Java + recursos decodificados + AndroidManifest.xml)
   na pasta escolhida.

## Por que compilar na nuvem (GitHub Actions) em vez de local

Você não tem PC, então este projeto **não inclui** o `gradlew`/`gradle-wrapper.jar`
binário (não há como gerar esse binário sem rede/Gradle instalado). Em vez
disso, o workflow em `.github/workflows/build.yml` instala o Gradle direto
no runner do GitHub e builda lá. Isso funciona 100% pelo navegador ou pelo
app do GitHub no celular.

### Passo a passo (só com o celular, sem extrair nada)

O workflow já foi ajustado para extrair o projeto sozinho dentro do
GitHub Actions. Você só precisa subir dois itens: um arquivo de texto
(criado colando o conteúdo) e o `.zip` puro, sem mexer nele.

1. Crie um repositório novo no GitHub (pode ser privado).
2. **"Add file" → "Create new file"**. No campo de nome, digite
   `.github/workflows/build.yml` (digitar as barras já cria as pastas
   automaticamente). Cole o conteúdo de `.github/workflows/build.yml`
   deste projeto no editor. Commit.
3. **"Add file" → "Upload files"**. Envie o `mc1h-apk-decompiler.zip`
   **como está**, sem extrair — fica na raiz do repositório. Commit.
4. O segundo commit já dispara o workflow sozinho. Vá na aba **Actions**
   do repositório e acompanhe o run "Build APK".
5. Quando terminar (ícone verde), abra o run → seção **Artifacts** →
   baixe `mc1h-apk-decompiler-debug` (vem como `.zip`, esse sim precisa
   ser extraído — é só o resultado do GitHub, não o projeto).
6. Extraia esse zip baixado (Files/Gerenciador de Arquivos do Android
   geralmente já extrai `.zip` direto) — dentro está o `.apk`.
7. Ao tocar no `.apk` para instalar, o Android vai pedir permissão
   "instalar apps desconhecidos" para o app que você usou para abrir o
   arquivo (Files, Chrome, etc.) — autorize e instale.

Alternativa, se você tiver Termux: dá para instalar `openjdk-17` +
`gradle` via `pkg install` e rodar `gradle :app:assembleDebug` direto no
aparelho, sem GitHub Actions. Mais pesado de configurar, mas sem depender
de nuvem.

## O que NÃO foi verificado aqui

Este ambiente onde o projeto foi gerado não tem Android SDK nem acesso de
rede, então **nada neste projeto foi compilado de fato**. A primeira
compilação real é o primeiro run do Actions. Pontos de maior risco, em
ordem de probabilidade de dar problema:

1. **`JadxArgs.setInputFile` / `.outDir`** (`JadxRunner.kt`): a API pública
   do jadx mudou nome de método entre versões. Segui o exemplo oficial da
   wiki (`github.com/skylot/jadx/wiki/Use-jadx-as-a-library`), mas se o
   build falhar com "unresolved reference" nessa linha, veja o comentário
   no topo do arquivo — já deixei as alternativas mais prováveis anotadas.
2. **Artefato `jadx-dex-input` no JitPack**: assumi que o fork
   `MuntashirAkon/jadx-android` publica esse módulo com o mesmo nome do
   projeto original. Se o Gradle não conseguir resolver essa dependência,
   confira os módulos realmente publicados em
   `https://jitpack.io/#MuntashirAkon/jadx-android` e ajuste o nome exato
   em `app/build.gradle.kts`.
3. **Versões fixadas** (AGP 8.5.2, Gradle 8.7, Kotlin 1.9.24, compileSdk/targetSdk 35):
   são versões estáveis conhecidas na época em que isso foi escrito. Se
   alguma already estiver obsoleta a ponto de sair do ar nos repositórios,
   o log do Actions vai apontar exatamente qual.

Se o primeiro build falhar, me manda o log de erro do Actions (a parte
relevante, não precisa colar tudo) que eu ajusto direto no código.

## Limitações conhecidas (v1)

- Decompila **APK/DEX** (código Java + recursos). Bibliotecas nativas
  (`.so`) não são desmontadas nesta versão — ficam só como binário dentro
  da pasta de saída, sem desassembly. Dá para adicionar depois (Capstone
  via JNI), é trabalho à parte.
- Sem fila de múltiplos arquivos: um APK por vez.
- Sem visualizador de código dentro do próprio app — o resultado é escrito
  como arquivos normais na pasta que você escolheu; abra com qualquer
  gerenciador de arquivos ou editor de texto do seu gosto.
- `minifyEnabled = false` nos dois build types — se mudar isso, o jadx usa
  reflection internamente e vai precisar de regras ProGuard/R8 específicas
  que ainda não existem aqui.
