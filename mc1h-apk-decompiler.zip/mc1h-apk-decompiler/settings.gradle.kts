pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Necessário para o jadx-android (fork mantido para uso em apps Android).
        // Fonte: https://jitpack.io/#MuntashirAkon/jadx-android
        maven(url = "https://jitpack.io")
    }
}

rootProject.name = "mc1h-apk-decompiler"
include(":app")
