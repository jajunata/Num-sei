# Sonora — Android music player (offline MVP)

Aplicativo Android gratuito, sem anúncios e sem assinatura. Esta etapa implementa importação de arquivos de áudio locais, reprodução real com AndroidX Media3/ExoPlayer, busca local, favoritos e persistência da lista de faixas/favoritos via SharedPreferences.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 36 instalado
- Dispositivo Android 8.0 (API 26) ou superior

## Executar
1. Extraia o ZIP.
2. Abra a pasta no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute no emulador ou aparelho.
5. Na tela inicial, toque em **Importar músicas do aparelho** e selecione um arquivo de áudio.

## Implementado nesta versão
- Interface Android em Kotlin + Jetpack Compose.
- Importação de áudio via seletor de documentos do Android.
- Reprodução/pausa real com ExoPlayer.
- Pesquisa entre faixas importadas.
- Favoritos persistidos localmente.
- Lista de faixas persistida localmente.
- Reprodução sem internet dos arquivos locais.

## Limitações conhecidas
- A reprodução ainda não continua com o app fechado ou em segundo plano: falta implementar MediaSessionService e notificação de mídia.
- A fila, playlists personalizadas, edição de metadados, capa do álbum e controle de progresso ainda não foram implementados.
- Favoritos e biblioteca são locais ao aparelho, sem sincronização em nuvem.
- A disponibilidade offline depende de o arquivo continuar acessível no dispositivo.
- Não há backend nem catálogo de streaming nesta etapa.

## Direitos autorais
Importe apenas arquivos que você possui ou está autorizado a reproduzir. O app não baixa músicas de terceiros, não contorna DRM e não se conecta a APIs privadas de serviços de streaming.
