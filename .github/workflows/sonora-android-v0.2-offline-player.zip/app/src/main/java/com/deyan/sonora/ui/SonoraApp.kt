package com.deyan.sonora.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray

private enum class Tab(val label: String) { Home("Início"), Search("Buscar"), Library("Biblioteca") }
private data class LocalTrack(val uri: String, val title: String)

@Composable
fun SonoraApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("sonora_local", 0) }
    val tracks = remember {
        mutableStateListOf<LocalTrack>().apply {
            val saved = runCatching { JSONArray(prefs.getString("tracks", "[]")) }.getOrNull()
            if (saved != null) for (i in 0 until saved.length()) {
                val item = saved.optJSONObject(i) ?: continue
                add(LocalTrack(item.optString("uri"), item.optString("title", "Áudio local")))
            }
        }
    }
    val favorites = remember {
        mutableStateListOf<String>().apply {
            prefs.getStringSet("favorites", emptySet())?.let { addAll(it) }
        }
    }
    var selectedTab by remember { mutableStateOf(Tab.Home) }
    var currentUri by remember { mutableStateOf<String?>(null) }
    var currentTitle by remember { mutableStateOf("Nenhuma faixa selecionada") }
    var isPlaying by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            })
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }

    fun persistTracks() {
        val array = JSONArray()
        tracks.forEach { track ->
            array.put(org.json.JSONObject().put("uri", track.uri).put("title", track.title))
        }
        prefs.edit().putString("tracks", array.toString()).apply()
    }
    fun play(track: LocalTrack) {
        currentUri = track.uri
        currentTitle = track.title
        player.setMediaItem(MediaItem.fromUri(Uri.parse(track.uri)))
        player.prepare()
        player.play()
    }
    fun toggleFavorite(track: LocalTrack) {
        if (favorites.contains(track.uri)) favorites.remove(track.uri) else favorites.add(track.uri)
        prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
    }

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            val name = uri.lastPathSegment?.substringAfterLast(':')?.substringAfterLast('/') ?: "Áudio local"
            if (tracks.none { it.uri == uri.toString() }) {
                tracks.add(LocalTrack(uri.toString(), name))
                persistTracks()
            }
            play(LocalTrack(uri.toString(), name))
        }
    }

    Scaffold(
        containerColor = Color(0xFF101010),
        bottomBar = {
            Column {
                MiniPlayer(
                    title = currentTitle,
                    isPlaying = isPlaying,
                    hasTrack = currentUri != null,
                    onToggle = {
                        if (player.isPlaying) player.pause()
                        else if (player.mediaItemCount > 0) player.play()
                    }
                )
                NavigationBar(containerColor = Color(0xFF080808)) {
                    NavigationBarItem(selectedTab == Tab.Home, { selectedTab = Tab.Home }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                    NavigationBarItem(selectedTab == Tab.Search, { selectedTab = Tab.Search }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Buscar") })
                    NavigationBarItem(selectedTab == Tab.Library, { selectedTab = Tab.Library }, icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Biblioteca") })
                }
            }
        }
    ) { padding ->
        when (selectedTab) {
            Tab.Home -> HomeScreen(
                modifier = Modifier.padding(padding),
                trackCount = tracks.size,
                onImport = { audioPicker.launch(arrayOf("audio/*")) },
                onOpenLibrary = { selectedTab = Tab.Library }
            )
            Tab.Search -> SearchScreen(
                modifier = Modifier.padding(padding),
                query = search,
                onQuery = { search = it },
                tracks = tracks.filter { it.title.contains(search, ignoreCase = true) },
                favorites = favorites,
                onPlay = ::play,
                onFavorite = ::toggleFavorite
            )
            Tab.Library -> LibraryScreen(
                modifier = Modifier.padding(padding),
                tracks = tracks,
                favorites = favorites,
                onImport = { audioPicker.launch(arrayOf("audio/*")) },
                onPlay = ::play,
                onFavorite = ::toggleFavorite
            )
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    trackCount: Int,
    onImport: () -> Unit,
    onOpenLibrary: () -> Unit
) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            Spacer(Modifier.height(28.dp))
            Text("Sonora", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
            Text("Sua música, do seu jeito.", color = Color.LightGray)
            Spacer(Modifier.height(26.dp))
            Text("Sua biblioteca offline", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF1E3B2D), RoundedCornerShape(12.dp))
                    .clickable(onClick = onOpenLibrary).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.LibraryMusic, null, tint = Color(0xFF35D07F), modifier = Modifier.size(38.dp))
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("$trackCount faixas adicionadas", fontWeight = FontWeight.Bold)
                    Text("Arquivos disponíveis neste aparelho", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Default.ChevronRight, null)
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Importar músicas do aparelho")
            }
            Spacer(Modifier.height(24.dp))
            Text("Como funciona", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Adicione arquivos de áudio que você possui ou tem autorização para usar. O Sonora reproduz esses arquivos sem precisar de internet.",
                color = Color.LightGray
            )
            Spacer(Modifier.height(12.dp))
            Text("Gratuito • Sem anúncios • Offline", color = Color(0xFF35D07F), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun SearchScreen(
    modifier: Modifier,
    query: String,
    onQuery: (String) -> Unit,
    tracks: List<LocalTrack>,
    favorites: List<String>,
    onPlay: (LocalTrack) -> Unit,
    onFavorite: (LocalTrack) -> Unit
) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Buscar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar nas suas músicas") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
        )
        Spacer(Modifier.height(14.dp))
        if (tracks.isEmpty()) Text("Nenhuma faixa encontrada. Importe músicas pela tela inicial.", color = Color.LightGray)
        else LazyColumn { items(tracks, key = { it.uri }) { track ->
            TrackRow(track, favorites.contains(track.uri), { onPlay(track) }, { onFavorite(track) })
        } }
    }
}

@Composable
private fun LibraryScreen(
    modifier: Modifier,
    tracks: List<LocalTrack>,
    favorites: List<String>,
    onImport: () -> Unit,
    onPlay: (LocalTrack) -> Unit,
    onFavorite: (LocalTrack) -> Unit
) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Sua Biblioteca", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onImport) { Icon(Icons.Default.Add, contentDescription = "Importar áudio") }
        }
        Text("${tracks.size} faixas no aparelho", color = Color.LightGray)
        Spacer(Modifier.height(12.dp))
        if (tracks.isEmpty()) {
            Text("Sua biblioteca está vazia.", color = Color.LightGray)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onImport) { Text("Adicionar primeira música") }
        } else {
            LazyColumn { items(tracks, key = { it.uri }) { track ->
                TrackRow(track, favorites.contains(track.uri), { onPlay(track) }, { onFavorite(track) })
            } }
        }
    }
}

@Composable
private fun TrackRow(track: LocalTrack, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onPlay).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).background(Color(0xFF263B30), RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null, tint = Color(0xFF35D07F))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text("Arquivo local", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Favoritar", tint = if (favorite) Color(0xFF35D07F) else Color.White)
        }
        IconButton(onClick = onPlay) { Icon(Icons.Default.PlayArrow, contentDescription = "Reproduzir") }
    }
}

@Composable
private fun MiniPlayer(title: String, isPlaying: Boolean, hasTrack: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF292929)).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Album, null, tint = Color(0xFF35D07F), modifier = Modifier.size(38.dp))
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (hasTrack) "Biblioteca offline" else "Importe uma música para começar", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
        }
        IconButton(onClick = onToggle, enabled = hasTrack) {
            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Reproduzir ou pausar")
        }
    }
}
